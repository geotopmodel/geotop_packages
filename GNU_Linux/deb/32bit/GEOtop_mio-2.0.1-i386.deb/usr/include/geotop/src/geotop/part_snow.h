
#ifndef __PART_SNOW__
#define __PART_SNOW__

#include "constants.h"

void part_snow(double prec_total, double *prec_rain, double *prec_snow, double temperature, double t_rain, double t_snow);

#endif

