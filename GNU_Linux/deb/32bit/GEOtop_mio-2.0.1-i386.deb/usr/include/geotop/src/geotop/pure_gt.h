/*
 * pure_gt.h
 *
 *  Created on: Mar 21, 2012
 *      Author: noori
 */
#ifdef USE_GEOTOP
#ifndef PURE_GT_H_
#define PURE_GT_H_














#endif /* PURE_GT_H_ */
#endif // USE_GEOTOP
